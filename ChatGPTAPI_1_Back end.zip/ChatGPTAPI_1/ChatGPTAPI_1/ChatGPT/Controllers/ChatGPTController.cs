﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OpenAI_API;
using OpenAI_API.Completions;

namespace ChatGPT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChatGPTController : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> UseChatGPT(string input)
        {
            string OutputResult = "";
            var openAI = new OpenAIAPI("use your API KEY");
            CompletionRequest completionRequest = new CompletionRequest();
            completionRequest.Prompt = input;
            completionRequest.Model = OpenAI_API.Models.Model.DavinciText;

            var completions = openAI.Completions.CreateCompletionAsync(completionRequest);

            foreach (var completion in completions.Result.Completions)
            {
                OutputResult += completion.Text;
            }

            return Ok(OutputResult);
        }
        
    }
}
